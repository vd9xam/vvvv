# Implementation gates

1. Obtain access to the actual Windows PC game installation and its Silksong managed assemblies; identify game version and player/controller classes without redistributing game files.
2. Inspect existing Melty-compatible Silksong co-op mods first and inspect Melty's `game_info` and multiplayer setup results.
3. Install/use the Melty-provided BepInEx 5 loader only through Melty's recipe.
4. Implement a minimal BepInEx plugin that locates the local player and safely reads its transform/action state; prove the hook in a real run.
5. Add host/join session setup and remote visual representation; do not synchronize enemy/boss logic until basic two-client movement is stable.
6. Add Melty multiplayer integration (`melty.properties`, `melty.log`, recipe multiplayer block) and test host plus a second game instance. If the game cannot be run twice locally, leave joining unverified.
7. Build/package only after preflight sheets are complete, then run Melty package/recipe/one-click checks, capture a real gameplay screenshot, and test the installed release.
8. Do not publish until the release has a real playable build and verified media.


## Multiplayer scope update
Support 2–4 players across separate PCs. Do not claim multiplayer is working until host/join flow and synchronization are tested with at least two separate game instances; test up to four players before claiming full 2–4-player support.
