# Silksong Co-op — Draft

**Status:** design/source preparation only; not a playable build and not tested.

## Intended first playable version
- Host game: Hollow Knight: Silksong (Unity; BepInEx 5 is the Melty-provided loader route).
- Players: exactly 2, each on a separate PC.
- Core loop: each player controls their own Hornet-like player instance in the same Silksong level; see the other player move; synchronize position/facing and basic action state; keep ordinary Silksong combat local until reliable game hooks are identified.
- Join flow: Melty-generated host/join address, no manual port forwarding. Network join/host integration is not implemented yet.
- Out of scope for first slice: It Takes Two content, extra levels, progression/save sharing, full enemy/boss authority, public matchmaking.

## Important publishing constraint
This is a Silksong-only co-op mod, not a Silksong × It Takes Two mashup. It cannot be listed as a mashup requiring both selected games unless It Takes Two contributes real gameplay/content or runs alongside Silksong and communicates with it. Do not tag it as a two-game mashup as a workaround.

## Build status
No game install, game assemblies, project source, Melty tools, or running Windows game were available in the current execution environment. Therefore no game-specific hooks can be verified and no playable build or gameplay screenshot is claimed. This folder is a planning artifact only.


## Updated player target
- Online co-op for 2–4 players on separate PCs.
- This is a target specification only; networking, compatibility, and gameplay are not yet implemented or tested.
